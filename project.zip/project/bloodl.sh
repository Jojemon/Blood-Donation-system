#!/bin/bash

# File Definitions
DONORS_FILE="donors.csv"
RECIPIENTS_FILE="recipients.csv"
USERS_FILE="users.csv"
LOG_FILE="./logs/operations.log"

# Function to log actions
log_action() {
    mkdir -p "$(dirname "$LOG_FILE")"
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
}

# Initialize files
initialize_files() {
    touch "$DONORS_FILE" "$RECIPIENTS_FILE" "$USERS_FILE"
    if [ ! -s "$DONORS_FILE" ]; then
        echo "ID,Username,Name,Age,BloodGroup,Contact,Location,Availability" > "$DONORS_FILE"
    fi
    if [ ! -s "$RECIPIENTS_FILE" ]; then
        echo "ID,Username,Name,Contact,Location" > "$RECIPIENTS_FILE"
    fi
    if [ ! -s "$USERS_FILE" ]; then
        echo "Username,Password,Role" > "$USERS_FILE"
    fi
    log_action "Initialized files"
}

# Validate phone number
validate_phone_number() {
    local phone="$1"
    if [[ "$phone" =~ ^[0-9]{11}$ ]]; then
        if grep -q ",$phone," "$DONORS_FILE" || grep -q ",$phone," "$RECIPIENTS_FILE"; then
            echo "Phone number already exists! Please enter a unique phone number."
            return 1
        else
            return 0
        fi
    else
        echo "Invalid phone number! It must be a unique 11-digit number."
        return 1
    fi
}

# Validate username
validate_unique_username() {
    local username="$1"
    if grep -q "^$username," "$USERS_FILE"; then
        echo "Username is already taken. Please choose a different username."
        return 1
    else
        return 0
    fi
}

perform_backup() {

SOURCE="/home/zatex/project/donors.csv"
DESTINATION="/home/zatex/project/blood"
DATE=$(date '+%Y-%m-%d_%H-%M-%S')


    if [ ! -f "$SOURCE" ]; then
        echo "Error: Source file does not exist: $SOURCE" | tee -a "$DESTINATION/backup_error.log"
        exit 1
    fi

    if [ ! -d "$DESTINATION" ]; then
        mkdir -p "$DESTINATION"
    fi

    tar -czf "$DESTINATION/backup_$DATE.tar.gz" "$SOURCE"
    if [ $? -eq 0 ]; then
        echo "[$(date)] Backup complete: $DESTINATION/backup_$DATE.tar.gz" | tee -a "$DESTINATION/backup_log.log"
    else
        echo "[$(date)] Backup failed" | tee -a "$DESTINATION/backup_error.log"
        exit 1
    fi
}
# Donor Registration
register_donor() {
    echo "Donor Registration:"
    while true; do
        read -p "Enter a unique username: " username
        if validate_unique_username "$username"; then
            break
        fi
    done

    read -sp "Enter a password: " password
    echo
    echo "$username,$password,donor" >> "$USERS_FILE"

    while true; do
        read -p "Name: " name
        [[ -n "$name" ]] && break || echo "Name cannot be empty!"
    done

    while true; do
        read -p "Age: " age
        [[ "$age" =~ ^[0-9]+$ && "$age" -gt 0 ]] && break || echo "Invalid age! Please enter a positive number."
    done

    while true; do
        read -p "Blood Group (O+/O-/A+/A-/B+/B-/AB+/AB-): " blood_group
        case "$blood_group" in
            "O-"|"O+"|"A-"|"A+"|"B-"|"B+"|"AB-"|"AB+") break ;;
            *) echo "Invalid blood group! Please enter one of: O-, O+, A-, A+, B-, B+, AB-, AB+." ;;
        esac
    done

    while true; do
        read -p "Contact (11-digit number): " contact
        validate_phone_number "$contact" && break
    done

    while true; do
        read -p "Location: " location
        [[ -n "$location" ]] && break || echo "Location cannot be empty!"
    done

    while true; do
        read -p "Are you currently available for blood donation? (yes/no): " availability
        [[ "$availability" =~ ^(yes|no)$ ]] && break || echo "Invalid input! Enter 'yes' or 'no'."
    done

    id=$(($(tail -n +2 "$DONORS_FILE" | wc -l) + 1))
    echo "$id,$username,$name,$age,$blood_group,$contact,$location,$availability" >> "$DONORS_FILE"
    log_action "Registered Donor: $username"
    echo "Donor registration completed successfully!"
    perform_backup
}

# Recipient Registration
register_recipient() {
    echo "Recipient Registration:"
    while true; do
        read -p "Enter a unique username: " username
        if validate_unique_username "$username"; then
            break
        fi
    done

    read -sp "Enter a password: " password
    echo
    echo "$username,$password,recipient" >> "$USERS_FILE"

    while true; do
        read -p "Name: " name
        [[ -n "$name" ]] && break || echo "Name cannot be empty!"
    done

    while true; do
        read -p "Contact (11-digit number): " contact
        validate_phone_number "$contact" && break
    done

    while true; do
        read -p "Location: " location
        [[ -n "$location" ]] && break || echo "Location cannot be empty!"
    done

    id=$(($(tail -n +2 "$RECIPIENTS_FILE" | wc -l) + 1))
    echo "$id,$username,$name,$contact,$location" >> "$RECIPIENTS_FILE"
    log_action "Registered Recipient: $username"
    echo "Recipient registration completed successfully!"
    perform_backup
}

# Admin Dashboard
admin_dashboard() {
    while true; do
        echo "Admin Dashboard:"
        echo "1. View All Donors"
        echo "2. View All Recipients"
        echo "3. Exit to Main Menu"
        read -p "Choose an option: " choice

        case $choice in
            1)
                echo "Registered Donors:"
                column -t -s',' "$DONORS_FILE"
                ;;
            2)
                echo "Registered Recipients:"
                column -t -s',' "$RECIPIENTS_FILE"
                ;;
            3)
                echo "Exiting Admin Dashboard..."
                break
                ;;
            *)
                echo "Invalid option! Please try again."
                ;;
        esac
    done
}

# Update Login Function for Admin Rolettttt
login_user() {
    read -p "Enter username: " username
    read -sp "Enter password: " password
    echo

    if grep -q "^$username,$password," "$USERS_FILE"; then
        role=$(grep "^$username,$password," "$USERS_FILE" | cut -d',' -f3)
        echo "Login successful!"
        log_action "User logged in: $username as $role"
        if [ "$role" == "donor" ]; then
            donor_menu "$username"
        elif [ "$role" == "recipient" ]; then
            recipient_menu
        elif [ "$role" == "admin" ]; then
            admin_dashboard
        fi
    else
        echo "Invalid username or password. Please try again."
    fi
}
# Donor Menu
donor_menu() {
    local username="$1"
    while true; do
    	echo "Logged in as Donor"
        echo "1. Update Availability"
        echo "2. Log Out"
        read -p "Choose an option: " option

        case $option in
            1)
                while true; do
                    read -p "Are you currently available for blood donation? (yes/no): " availability
                    if [[ "$availability" =~ ^(yes|no)$ ]]; then
                        awk -F',' -v user="$username" -v avail="$availability" 'BEGIN {OFS=","}
                        NR==1 {print; next}
                        $2==user {$8=avail} {print}' "$DONORS_FILE" > temp && mv temp "$DONORS_FILE"
                        log_action "Updated availability for $username to $availability"
                        echo "Availability updated successfully!"
                        perform_backup
                        break
                    else
                        echo "Invalid input! Enter 'yes' or 'no'."
                    fi
                done
                ;;
            2)
                echo "Logging out..."
                log_action "Donor logged out: $username"
                break
                ;;
            *)
                echo "Invalid option! Please try again."
                ;;
        esac
    done
}

search_donors() {
    echo "Search Donors:"
    read -p "Enter Blood Group (optional): " blood_group
    read -p "Enter Location (optional): " location

    awk -F',' -v bg="$blood_group" -v loc="$location" '
    BEGIN {OFS="\t"; print "ID", "Name", "Age", "BloodGroup", "Contact", "Location", "Availability"}
    NR > 1 && ($5 == bg || bg == "") && ($7 == loc || loc == "") {print $1, $3, $4, $5, $6, $7, $8}
    ' "$DONORS_FILE"
}
emergency_request() {
    echo "Emergency Blood Request:"
    read -p "Enter Blood Group: " blood_group
    read -p "Enter Your Location: " location

    available_donors=$(awk -F',' -v bg="$blood_group" -v loc="$location" '
    NR > 1 && $5 == bg && $7 == loc && $8 == "yes" {print $3 " (" $6 ")"}' "$DONORS_FILE")

    if [ -z "$available_donors" ]; then
        echo "No donors available for the specified blood group and location."
    else
        echo "Notifying the following donors:"
        echo "$available_donors"
        echo "Emergency request sent successfully!"
        log_action "Emergency request for blood group $blood_group at $location"
    fi
}
# Recipient Menu
recipient_menu() {
    while true; do
    	echo "Logged as Recipient"
        echo "1. Search for Available Donors"
        echo "2. Emergency Blood Request"
        echo "3. Log Out"
        read -p "Choose an option: " option

        case $option in
            1)  search_donors
                while true; do
                    read -p "Enter Blood Group: " blood_group
                    case "$blood_group" in
                        "O-"|"O+"|"A-"|"A+"|"B-"|"B+"|"AB-"|"AB+")
                            echo "Searching for available donors..."
                            available_donors=$(awk -F',' -v bg="$blood_group" 'NR>1 && $5==bg && $8=="yes" {print}' "$DONORS_FILE")
                            if [ -z "$available_donors" ]; then
                                echo "No donors available for the specified blood group."
                            else
                                echo "Available Donors:"
                                awk -F',' -v bg="$blood_group" 'BEGIN {OFS=","; print "ID","Name","Age","BloodGroup","Contact","Location","Availability"}
                                NR>1 && $5==bg && $8=="yes" {print}' "$DONORS_FILE"
                            fi
                            break ;;
                        *) echo "Invalid blood group! Please enter one of: O-, O+, A-, A+, B-, B+, AB-, AB+." ;;
                    esac
                done
                ;;
            2)  emergency_request
                ;;
            3)
                echo "Logging out..."
                log_action "Recipient logged out"
                break
                ;;
            *)
                echo "Invalid option! Please try again."
                ;;
        esac
    done
}



# Main Menu
main_menu() {
    initialize_files
    while true; do
        echo "====================Welcome to BloodLink ===================="
        echo "1. Register as Donor"
        echo "2. Register as Recipient"
        echo "3. Login"
        echo "4. Exit"
        read -p "Choose an option: " option

        case $option in
            1) register_donor ;;
            2) register_recipient ;;
            3) login_user ;;
            4) perform_backup;
                echo "Thank you for being a part of BloodLink"
                log_action "System exited."
                break
                ;;
            *)
                echo "Invalid option! Please choose a valid menu option."
                ;;
        esac
    done
}

# Start the main menu
main_menu



